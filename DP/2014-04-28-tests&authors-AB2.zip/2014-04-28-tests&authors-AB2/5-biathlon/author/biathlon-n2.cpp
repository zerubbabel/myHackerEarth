//Task: biathlon - O(n^2)
//Author: Rusko Shikov

#include <cstdio>
#include <string.h>
const int nmax=1000000;

int tinv[nmax+1];
int perm[nmax+1];

int n;

void input()
{
    int i;
    scanf("%d",&n);
    for (i=1;i<=n;i++)
      scanf("%d",&tinv[i]);
    memset(perm,0,sizeof(perm));  
}

int main()
{
    int i,j,czero;
    input();
    for (i=1;i<=n;i++)
    {
        czero=0;
        j=0;
        while (czero<=tinv[i])
        {
            j++;
            if (perm[j]==0) czero++;
        }
        perm[j]=i;
    }
    
    for (i=1;i<=n;i++)
      printf("%d\n",perm[i]);
   
    
}