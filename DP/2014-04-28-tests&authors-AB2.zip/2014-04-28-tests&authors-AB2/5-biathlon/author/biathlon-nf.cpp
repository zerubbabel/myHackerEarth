//Task: biathlon - O(n!)
//Author: Rusko Shikov

#include <cstdio>
#include <algorithm>
using namespace std;

const int nmax=1000000;
int tinv[nmax+1];
int perm[nmax+1];

int n;

void init()
{
  int i;  
  scanf("%d",&n);
  for (i=1;i<=n;i++)
    scanf("%d",&tinv[i]);
  for (i=1;i<=n;i++)
    perm[i]=i;    
}

bool eq()
{
   int vtinv[12];
   int c,i,j,k;
   bool fl;
   for (i=1;i<=n;i++)
   {
     c=0;
     j=perm[i];
     for (k=1;k<i;k++)
       if (perm[k]>j) c++;
     vtinv[j]=c;   
   }  
   fl=true;
   for (i=1;(i<=n) && fl;i++)
     fl=(tinv[i]==vtinv[i]);
     
   return fl;   
}

int main()
{
   int i; 
   init(); 
   while (!eq())
     next_permutation(perm+1, perm+n+1);
   for (i=1;i<=n;i++)
     printf("%d\n", perm[i]);
    
}
