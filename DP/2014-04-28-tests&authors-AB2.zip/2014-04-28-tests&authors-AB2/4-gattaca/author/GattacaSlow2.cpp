/*
ID: espr1t
TASK: Gattaca
KEYWORDS: Medium, Binary Search, Dummy
*/

#include <cstdio>
#include <algorithm>
#include <vector>

using namespace std;
const int MAX = 131072;

int n, m, k;
char a[MAX], b[MAX];
int startIdx = -1, bestLen = -1;


bool eval(int len, bool update) {
    vector < pair <string, int> > s1;
    for (int start = 0; start + len <= n; start++) {
        string add;
        for (int i = 0; i < len; i++)
            add.push_back(a[start + i]);
        s1.push_back(make_pair(add, start));
    }
    sort(s1.begin(), s1.end());
    
    vector <string> s2;
    for (int start = 0; start + len <= m; start++) {
        string add;
        for (int i = 0; i < len; i++)
            add.push_back(b[start + i]);
        s2.push_back(add);
    }
    sort(s2.begin(), s2.end());
    
    int left = 0, right = 0;
    for (int i = 0; i < (int)s1.size(); i++) {
        if (i > 0 && s1[i - 1].first == s1[i].first)
            continue;
        while (left < (int)s2.size() && s2[left] < s1[i].first)
            left++;
        if (left < (int)s2.size() && s2[left] == s1[i].first) {
            right = left;
            while (right < (int)s2.size() && s2[left] == s2[right])
                right++;
            if (right - left >= k) {
                if (update && bestLen < len)
                    bestLen = len, startIdx = s1[i].second;
                return true;
            }
            left = right;
        }
    }
    return false;
}


int main(void) {
    FILE* in = stdin; FILE* out = stdout;
//    in = fopen("Gattaca.in", "rt"); out = fopen("Gattaca.out", "wt");

    fscanf(in, "%d %d %d", &n, &m, &k);
    fscanf(in, "%s %s", a, b);
    
    int left = 1, right = 2;
    while (eval(right, false))
        left = right, right = right * 2;
    right = min(right, min(n, m - k + 1));
    while (left <= right) {
        int mid = (left + right) / 2;
        if (eval(mid, false))
            left = mid + 1;
        else
            right = mid - 1;
    }
    eval(right, true);
    for (int i = 0; i < bestLen; i++)
        fprintf(out, "%c", a[startIdx + i]);
    fprintf(out, "\n");
    return 0;
}
