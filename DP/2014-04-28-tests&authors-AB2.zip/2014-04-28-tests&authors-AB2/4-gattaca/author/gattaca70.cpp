/*
ID: espr1t
TASK: Gattaca
KEYWORDS: Medium, Binary Search, Hashing
*/

#include <cstdio>
#include <algorithm>
#include <vector>

using namespace std;
const int MAX = 131072;

int n, m, k;
char a[MAX], b[MAX];

const int NUM_HASHES = 3;
const int BASE[NUM_HASHES] = {131, 137, 139};
const int MOD[NUM_HASHES] = {7200007, 7200023, 7200043};
int basePow[NUM_HASHES][MAX];

// Simple rolling-hash implementation with triple-hashing.
struct Hash {
    vector <int> h;
    Hash() {
        h.resize(NUM_HASHES, 0);
    }
    void appendBack(char ch) {
        for (int i = 0; i < (int)h.size(); i++)
            h[i] = (h[i] * BASE[i] + ch) % MOD[i];
    }
    void removeFront(char ch, int len) {
        for (int i = 0; i < (int)h.size(); i++) {
            h[i] -= (ch * basePow[i][len - 1]) % MOD[i];
            if (h[i] < 0)
                h[i] += MOD[i];
        }
    }
    bool operator < (const Hash& r) const {return h < r.h;}
    bool operator == (const Hash& r) const {return h == r.h;}
};

void initHashes() {
    for (int i = 0; i < NUM_HASHES; i++) {
        basePow[i][0] = 1;
        for (int c = 1; c < MAX; c++)
            basePow[i][c] = (basePow[i][c - 1] * BASE[i]) % MOD[i];
    }
}

int startIdx = -1, bestLen = -1;
void updateAnswer(int idx, int len) {
    if (bestLen < len)
        bestLen = len, startIdx = idx;
    else if (bestLen == len) {
        for (int i = 0; i < len; i++) {
            if (a[startIdx + i] != a[idx + i]) {
                if (a[startIdx + i] > a[idx + i])
                    startIdx = idx;
                break;
            }
        }
    }
}

bool eval(int len, bool update) {
    Hash h1;
    vector < pair <Hash, int> > s1;
    for (int i = 0; i < len - 1; i++)
        h1.appendBack(a[i]);
    for (int i = len - 1; i < n; i++) {
        h1.appendBack(a[i]);
        s1.push_back(make_pair(h1, i - len + 1));
        h1.removeFront(a[i - len + 1], len);
    }
    sort(s1.begin(), s1.end());

    Hash h2;
    vector <Hash> s2;
    for (int i = 0; i < len - 1; i++)
        h2.appendBack(b[i]);
    for (int i = len - 1; i < m; i++) {
        h2.appendBack(b[i]);
        s2.push_back(h2);
        h2.removeFront(b[i - len + 1], len);
    }
    sort(s2.begin(), s2.end());
    
    int left = 0, right = 0;
    for (int i = 0; i < (int)s1.size(); i++) {
        while (left < (int)s2.size() && s2[left] < s1[i].first)
            left++;
        if (left < (int)s2.size() && s2[left] == s1[i].first) {
            right = left;
            while (right < (int)s2.size() && s2[left] == s2[right])
                right++;
            if (right - left >= k) {
                if (!update)
                    return true;
                updateAnswer(s1[i].second, len);
            }
            left = right;
        }
    }
    return false;
}


int main(void) {
    FILE* in = stdin; FILE* out = stdout;
//    in = fopen("Gattaca.in", "rt"); out = fopen("Gattaca.out", "wt");

    initHashes();

    fscanf(in, "%d %d %d", &n, &m, &k);
    fscanf(in, "%s %s", a, b);

    int left = 1, right = min(n, m - k + 1);
    while (left <= right) {
        int mid = (left + right) / 2;
        if (eval(mid, false))
            left = mid + 1;
        else
            right = mid - 1;
    }
    eval(right, true);
    for (int i = 0; i < bestLen; i++)
        fprintf(out, "%c", a[startIdx + i]);
    fprintf(out, "\n");
    return 0;
}
