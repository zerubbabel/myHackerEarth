/*
ID: espr1t
TASK: Gattaca
KEYWORDS: Medium, Binary Search, Hashing
*/

#include <cstdio>
#include <algorithm>
#include <string.h>

using namespace std;
const int MAX = 131072;

int n, m, k;
char a[MAX], b[MAX];

const unsigned BASE1 = 131;
const unsigned BASE2 = 137;
const unsigned BASE3 = 139;
unsigned basePow1[MAX];
unsigned basePow2[MAX];
unsigned basePow3[MAX];

const int NUM_BUCKETS = 131072;
const unsigned BUCKET_MOD = 131071;

// Simple rolling-hash implementation with triple-hashing.
struct Hash {
    unsigned h1, h2, h3;
    Hash() {
        h1 = h2 = h3 = 0;
    }
    void appendBack(char ch) {
        h1 = h1 * BASE1 + ch;
        h2 = h2 * BASE2 + ch;
        h3 = h3 * BASE3 + ch;
    }
    void removeFront(char ch, int len) {
        h1 -= basePow1[len - 1] * ch;
        h2 -= basePow2[len - 1] * ch;
        h3 -= basePow3[len - 1] * ch;
    }
    unsigned getBucket() {
        return (h1 ^ h2 ^ h3) % BUCKET_MOD;
    }
    bool operator < (const Hash& r) const {
         return h1 < r.h1 || (h1 == r.h1 && h2 < r.h2) ||
             (h1 == r.h1 && h2 == r.h2 && h3 < r.h3);
    }
    bool operator == (const Hash& r) const {
         return h1 == r.h1 && h2 == r.h2 && h3 == r.h3;
    }
};

void initHashes() {
    basePow1[0] = basePow2[0] = basePow3[0] = 1;
    for (int i = 1; i < MAX; i++) {
        basePow1[i] = basePow1[i - 1] * BASE1;
        basePow2[i] = basePow2[i - 1] * BASE2;
        basePow3[i] = basePow3[i - 1] * BASE3;
    }
}

int startIdx = -1, bestLen = -1;
void updateAnswer(int idx, int len) {
    if (bestLen < len)
        bestLen = len, startIdx = idx;
    else if (bestLen == len) {
        for (int i = 0; i < len; i++) {
            if (a[startIdx + i] != a[idx + i]) {
                if (a[startIdx + i] > a[idx + i])
                    startIdx = idx;
                break;
            }
        }
    }
}

int hlen[NUM_BUCKETS];
pair <Hash, pair <int, int> > hashes[NUM_BUCKETS][32];

bool eval(int len, bool update) {
    memset(hlen, 0, sizeof(hlen));

    Hash h1;
    for (int i = 0; i < len - 1; i++)
        h1.appendBack(a[i]);
    for (int i = len - 1; i < n; i++) {
        h1.appendBack(a[i]);
        bool found = false;
        int bucket = h1.getBucket();
        for (int c = 0; c < hlen[bucket]; c++) {
            if (hashes[bucket][c].first == h1) {
                found = true;
                break;
            }
        }
        if (!found)
            hashes[bucket][hlen[bucket]++] = make_pair(h1, make_pair(i - len + 1, 0));
        h1.removeFront(a[i - len + 1], len);
    }

    Hash h2;
    for (int i = 0; i < len - 1; i++)
        h2.appendBack(b[i]);
    for (int i = len - 1; i < m; i++) {
        h2.appendBack(b[i]);
        int bucket = h2.getBucket();
        for (int c = 0; c < hlen[bucket]; c++) {
            if (hashes[bucket][c].first == h2) {
                if (++hashes[bucket][c].second.second == k) {
                    if (!update)
                        return true;
                    updateAnswer(hashes[bucket][c].second.first, len);
                }
            }
        }
        h2.removeFront(b[i - len + 1], len);
    }
    return false;
}

int main(void) {
    FILE* in = stdin; FILE* out = stdout;
//    in = fopen("Gattaca.in", "rt"); out = fopen("Gattaca.out", "wt");

    initHashes();

    fscanf(in, "%d %d %d", &n, &m, &k);
    fscanf(in, "%s %s", a, b);

    int left = 1, right = min(n, m - k + 1);
    while (left <= right) {
        int mid = (left + right) / 2;
        if (eval(mid, false))
            left = mid + 1;
        else
            right = mid - 1;
    }
    eval(right, true);
    for (int i = 0; i < bestLen; i++)
        fprintf(out, "%c", a[startIdx + i]);
    fprintf(out, "\n");
    return 0;
}
