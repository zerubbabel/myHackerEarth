/*
ID: espr1t
TASK: Gattaca
KEYWORDS: Medium, Binary Search, Dummy
*/

#include <cstdio>
#include <algorithm>
#include <vector>

using namespace std;
const int MAX = 131072;

int n, m, k;
char a[MAX], b[MAX];

int startIdx = -1, bestLen = -1;
void updateAnswer(int idx, int len) {
    if (bestLen < len)
        bestLen = len, startIdx = idx;
    else if (bestLen == len) {
        for (int i = 0; i < len; i++) {
            if (a[startIdx + i] != a[idx + i]) {
                if (a[startIdx + i] > a[idx + i])
                    startIdx = idx;
                break;
            }
        }
    }
}

bool eval(int len, bool update) {
    for (int s1start = 0; s1start + len <= n; s1start++) {
        int cnt = 0;
        for (int s2start = 0; s2start + len <= m; s2start++) {
            int add = 1;
            for (int i = 0; i < len; i++)
                if (a[s1start + i] != b[s2start + i]) {add = 0; break;}
            cnt += add;
            if (cnt >= k) {
                if (!update)
                    return true;
                updateAnswer(s1start, len);
                break;
            }
        }
    }
    return false;
}


int main(void) {
    FILE* in = stdin; FILE* out = stdout;
//    in = fopen("Gattaca.in", "rt"); out = fopen("Gattaca.out", "wt");

    fscanf(in, "%d %d %d", &n, &m, &k);
    fscanf(in, "%s %s", a, b);

    int left = 1, right = min(n, m - k + 1);
    while (left <= right) {
        int mid = (left + right) / 2;
        if (eval(mid, false))
            left = mid + 1;
        else
            right = mid - 1;
    }
    eval(right, true);
    for (int i = 0; i < bestLen; i++)
        fprintf(out, "%c", a[startIdx + i]);
    fprintf(out, "\n");
    return 0;
}
