#include <iostream>
#include <stdio.h>
using namespace std;
const int M=1000000000+7;
const int MAXN=100005;
long long f[MAXN];//数据类型为long long
int fac(int n){
    f[1]=1;
    for(int i=2;i<=n;i++){        
        f[i] =f[i-1]*i % M;//乘法注意数据溢出
    }
    return f[n];
}
int main()
{
    int T,n;
    cin>>T;
    f[0]=1;//注意0的情况
    fac(MAXN);//先一次性算好否则时间复杂度T*N超时
    for(int i=0;i<T;i++){
        scanf("%d",&n);
        printf("%lld\n",f[n]);//long long 输出
    }
    return 0;
}
